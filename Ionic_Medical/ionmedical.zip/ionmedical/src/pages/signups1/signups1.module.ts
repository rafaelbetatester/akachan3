import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Signups1Page } from './signups1';

@NgModule({
  declarations: [
    Signups1Page,
  ],
  imports: [
    IonicPageModule.forChild(Signups1Page),
  ],
})
export class Signups1PageModule {}
