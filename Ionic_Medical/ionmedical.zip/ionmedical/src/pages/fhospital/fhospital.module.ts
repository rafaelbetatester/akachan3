import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FhospitalPage } from './fhospital';

@NgModule({
  declarations: [
    FhospitalPage,
  ],
  imports: [
    IonicPageModule.forChild(FhospitalPage),
  ],
})
export class FhospitalPageModule {}
